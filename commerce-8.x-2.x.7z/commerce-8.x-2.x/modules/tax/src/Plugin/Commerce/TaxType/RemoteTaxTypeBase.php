<?php

namespace Drupal\commerce_tax\Plugin\Commerce\TaxType;

/**
 * Provides the base class for remote tax types.
 */
abstract class RemoteTaxTypeBase extends TaxTypeBase implements RemoteTaxTypeInterface {}
